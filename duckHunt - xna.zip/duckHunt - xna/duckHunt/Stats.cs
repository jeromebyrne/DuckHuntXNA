using System;
using System.Collections.Generic;
using System.Text;

namespace duckHunt
{
    public class Stats
    {
        private float d_score;// whats the score

        private int maxScore;// what is the maximum score (the starting score)

        public Stats() // constructor
        {
            maxScore = 1000;
            d_score = maxScore;// set the starting sore to the max score
        }

        public void decrementScore(float value)// decrement the score by a certain value
        {
            d_score -= value;
        }

	    public int score
	    {
		    get { return (int)d_score;}
	    }

        public void reset()//reset the score back to the starting score
        {
            d_score = maxScore;
        }
	


    }
}
