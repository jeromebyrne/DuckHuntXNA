using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace duckHunt
{
    public class Bird : MovingObject // bird is derived from moving object
    {
        private bool d_isDead; // is the bird alive or dead

        private bool d_edgeContact; // is the bird in contact with the edge of the screen

        private int d_edgeContactCount;// how long until its not in contact again

        // the following indicate the correct sprite index for the variable name,
        // for example if the ducks direction is [-1,0] the it is going left so we
        // set the current sprite index of the bird to left.
        // this assumes that the textures for left, right, up ... etc are loaded in the order below
        private int left = 0;
        private int right = 1;
        private int up = 2;
        private int down = 3;
        private int upLeft = 4;
        private int upRight = 5;
        private int downLeft = 6;
        private int downRight = 7;
        private int dead = 8;

        public Bird(Vector2 position, int width, int height)
                    : base(position, width, height) // constructor
        {
            d_isDead = false;

            d_edgeContactCount = 3;
        }
        public bool isDead
        {
            get { return d_isDead; }
            set { d_isDead = value; }
        }

        public bool edgeContact
        {
            get { return d_edgeContact; } // returns wether the bird has hit the edge of the screen
            set { d_edgeContact = value; }

        }
        public void update()
        {
            move(); // move the bird

            if(d_edgeContact == true)// if it is hitting the edge of the screen
            {
                d_edgeContactCount--;// decrement the time until it is not touching the edge


                if (d_edgeContactCount <= 0)// if the time reaches 0
                {
                    d_edgeContactCount = 0;

                    d_edgeContact = false;// then we are no longer hitting the screen
                }
            }

            if(numSprites == 9) // if there are 9 sprites, 0-8
            {
                if(direction.X == -1 && direction.Y == 0)// looking left
                {
                    currentSpriteIndex = left;
                }

                else if (direction.X == 1 && direction.Y == 0)// looking right
                {
                    currentSpriteIndex = right;
                }

                else if (direction.X == 0 && direction.Y == -1)// looking up
                {
                    currentSpriteIndex = up;
                }

                // change to the dead bird sprite 
                else if (direction.X == 0 && direction.Y == 1 && d_isDead == true)
                {
                    currentSpriteIndex = dead;
                }

                else if (direction.X == 0 && direction.Y == 1)// looking down
                {
                    currentSpriteIndex = down;
                }

                else if (direction.X == 1 && direction.Y == 1)
                {
                    currentSpriteIndex = downRight;
                }

                else if (direction.X == 1 && direction.Y == -1)
                {
                    currentSpriteIndex = upRight;
                }

                else if (direction.X == -1 && direction.Y == -1)
                {
                    currentSpriteIndex = upLeft;
                }

                else if (direction.X == -1 && direction.Y == 1 )
                {
                    currentSpriteIndex = downLeft;
                }
            }
        }
	
	
    }
}
