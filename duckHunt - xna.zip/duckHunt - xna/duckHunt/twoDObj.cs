using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace duckHunt
{
    public class TwoDObj
    {
        private Vector2 d_position;// an X,Y position

        private int d_width;// width of the sprite

        private int d_height;// height of the sprite

        private Rectangle d_rectangle;// rectangle which holds sprite coordinates

        private int maxSprites = 9;// the max number of sprites for the object

        private Texture2D[] d_spriteArray;// an array of textures which will hold a maximum of maxSprites 

        private int d_numSprites = 0;// how many sprites are currently in our d_spriteArray

        private int d_currentSpriteIndex = 0;// what is the current sprite being shown

        Color d_color;// color of the current sprite

        public TwoDObj(Vector2 position,
                        int width, int height) // constructor
        {
            //initialise
            d_spriteArray = new Texture2D[maxSprites];

            d_position = position;

            d_width = width;

            d_height = height;

            d_rectangle = new Rectangle();

            d_rectangle.Height = d_height;

            d_rectangle.Width = d_width;

            d_color = Color.White;
            
        }

        //takes in a string and loads a texture from these details
        // needs the ContentManager Content from game1
        public void loadTexture(ContentManager content, string texName)
        {
            // if the maximum number of sprites has not been exceeded
            if (d_numSprites < maxSprites)
            {
                //create a new variable to hold the texture
                Texture2D tex; 

                //load the texture with the content manager we passed in
                tex = content.Load<Texture2D>(texName);

                // then put the texture into the array of sprites just after the last one
                d_spriteArray[d_numSprites] = tex;

                // we added a new sprite so increment by 1
                d_numSprites++;
            }
        }
        public Vector2 position // returns the vector 2 position
        {
            get { return d_position; }
            set { d_position = value; }
        }


        public Color color
        {
            get { return d_color; }
            set { d_color = value; }
        }
	
        public void drawSprite(SpriteBatch ForegroundBatch, bool alpha)
        {
                // position the rectangle around the position
                d_rectangle.X = (int)d_position.X - (d_width / 2);
                d_rectangle.Y = (int)d_position.Y - (d_height / 2);

                if (alpha == true)// do we want to blend 
                {
                    ForegroundBatch.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.BackToFront, SaveStateMode.SaveState);
                }

                else // or use additive
                {
                    ForegroundBatch.Begin(SpriteBlendMode.Additive, SpriteSortMode.BackToFront, SaveStateMode.SaveState);
                }
                
                // draw the current sprite selected in the sprite array
                ForegroundBatch.Draw(d_spriteArray[d_currentSpriteIndex], d_rectangle, d_color);

                ForegroundBatch.End();

        }
        public float X // returns the x position
        {
            get { return d_position.X; }
            set { d_position.X = value; }
        }

        

        public float Y // returns the y position 
        {
            get { return d_position.Y; }
            set { d_position.Y = value; }
        }

	
        public Rectangle rectangle
        {
            get { return d_rectangle;}// returns the rectangle
        }

         public Texture2D sprite
        {
            get { return d_spriteArray[d_currentSpriteIndex]; }// returns the current sprite texture being used
        }

        public int currentSpriteIndex 
        {
            get { return d_currentSpriteIndex; }//returns the index of the current sprite (where in the array)
            set { d_currentSpriteIndex = value; }// sets the current sprite index (used for changing to a different sprite)
        }

        public int numSprites// how many sprites does this TwoDObj contain
        {
            get { return d_numSprites; }
        }
	

    }//end of class
}//end of name space
