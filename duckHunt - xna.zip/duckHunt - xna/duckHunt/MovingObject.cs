using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;

namespace duckHunt
{
    public class MovingObject : TwoDObj // moving object is derived from TwoDObj (it is a TwoDObj)
    {
        private float d_speed;// the speed of the moving object

        Vector2 d_direction;// the direction the object is moving

        public MovingObject(Vector2 position,int width, int height) : 
                            base(position,width,height)
        {
            speed = 2; // set as the default value
            d_direction = new Vector2(1,1);// default

        }

        public float directionX
        {
            get { return d_direction.X; }
            set { d_direction.X = value; }
        }

        public float directionY
        {
            get { return d_direction.Y; }
            set { d_direction.Y = value; }
        }

	    public float speed
	    {
		    get { return d_speed;}
		    set { d_speed = value;}
	    }

        public Vector2 direction
        {
            get { return d_direction; }
            set { d_direction = value; }
        }

        public void move()
        {
            position = position + (direction * d_speed);
        }

        // rotates the direction of the moving object by a certain degrees
        public void rotate(float degrees)
        {
            float val = MathHelper.ToRadians(degrees); // converts the degrees to radians and stores in val

            //formula for rotation
            d_direction.X = Vector3.Transform(new Vector3(d_direction.X, d_direction.Y, 1), Matrix.CreateRotationZ(val)).X;
            d_direction.Y = Vector3.Transform(new Vector3(d_direction.X, d_direction.Y, 1), Matrix.CreateRotationZ(val)).Y;

            d_direction.Normalize();// not needed, its there just in case

        }

    }
}
