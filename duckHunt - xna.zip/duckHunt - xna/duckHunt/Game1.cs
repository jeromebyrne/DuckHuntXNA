using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace duckHunt
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch; // used for drawing sprites

        TwoDObj target; // the target used to shoot

        TwoDObj background;// the background picture 

        Bird bird; // the bird you will be shooting

        MouseState mouse; // keeps track of the mouse input

        MouseState preMouse; // the mouse input of the last frame

        Rectangle screenBounds;// the bounding rectangle of the screen

        Random random = new Random(); // random number generator

        SpriteFont arial; // font

        SpriteFont gothic; // font

        TwoDObj scoreSprite; // a sprite where the score will be displayed

        Hud hud = new Hud(); // create a new heads up display 

        Stats stats = new Stats(); // keeps track of score etc...

        TwoDObj blood; // displays a blood sprite when the main bird is shot

        int endScreenMaxTime = 300;// how many frames before the mainMenu pops up after a finished game
        int endScreenTime;// what frame (between 0 - endScreenMaxTime) 

        static public bool mouseLeftJustPressed = false; // has the left mouse button just been pressed and released (prevents holding down left mouse)

        static public bool startingNewGame = false; // are we starting a new game

        const int MAXBIRDS = 100; // the maximum number of birds on screen (not including target bird)

        public bool mainGameRunning = false; // are we playing a game

        MainMenu mainMenu; // a class which updates as a main menu

         public Bird[] birdArray = new Bird[MAXBIRDS];// create a new array of MAXBIRDS

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // setting screen resolution and fullscreen or not
            graphics.PreferredBackBufferWidth = 1024;
            graphics.PreferredBackBufferHeight = 768;
            graphics.IsFullScreen = true;
            graphics.ApplyChanges();


            endScreenTime = endScreenMaxTime;

            // creating a new crosshairs to shoot with
            target = new TwoDObj(new Vector2(0, 0), 120, 100); // constructor called

            //this is our target bird, the one we need to kill
            bird = new Bird(new Vector2(0, 0), 100, 100);// constructor called

            //a rectangle which represents our screen space
            screenBounds.X = 0;
            screenBounds.Y = 0;
            screenBounds.Width = graphics.PreferredBackBufferWidth;
            screenBounds.Height = graphics.PreferredBackBufferHeight;


            // initialise our bird array
            for (int i = 0; i < MAXBIRDS; i++)
            {
                birdArray[i] = new Bird(new Vector2(0, 0),
                                                100, 100);
            }

            // this is the background we will be looking at
            background = new TwoDObj(new Vector2(screenBounds.Width / 2, screenBounds.Height/2),
                            screenBounds.Width, screenBounds.Height); // constructor called

            // initialise our main menu, we need to tell it our screen size
            mainMenu = new MainMenu(screenBounds);

            // just a sprite where our score will be
            scoreSprite = new TwoDObj(new Vector2(screenBounds.Left +180,screenBounds.Bottom-80),350,100);

            // when the main bird is killed, show this sprite
            blood = new TwoDObj(new Vector2(0, 0), 300, 300);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            #region load our textures - NOTE : a region is used to enclose a chunk of code

            //we need to load our textures, note that loadTexture is not an inbuilt XNA 
            //  function but a function of our custom class TwoDObj
            target.loadTexture(Content, "Crosshairs");

            bird.loadTexture(Content, "crow");

            background.loadTexture(Content, "lake2");

            scoreSprite.loadTexture(Content, "window1");

            mainMenu.loadTextures(Content);

                for (int i = 0; i < MAXBIRDS; i++)
                {
                    birdArray[i].loadTexture(Content, "crowLeft");
                    birdArray[i].loadTexture(Content, "crowRight");
                    birdArray[i].loadTexture(Content, "crowUp");
                    birdArray[i].loadTexture(Content, "crowDown");
                    birdArray[i].loadTexture(Content, "crowLeftUp");
                    birdArray[i].loadTexture(Content, "crowRightUp");
                    birdArray[i].loadTexture(Content, "crowLeftDown");
                    birdArray[i].loadTexture(Content, "crowRightDown");
                    birdArray[i].loadTexture(Content, "crowDead");
                }
            #endregion

                blood.loadTexture(Content, "blood");

                //load our fonts we will be using to write text
                arial = Content.Load<SpriteFont>("Arial");
                gothic = Content.Load<SpriteFont>("gothic");

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {   
            // if we are in the middle of a game then ...
            if (mainGameRunning == true)
            {
                // ... we have to run the function which updates all of our stuff,
                //  birds position etc.
                mainGameLoop();
            }

            // if we are not in a game then we must be in the main menu...
            else
            {
                //... so we process our keys and mouse...
                processInput();

                //... then give our crosshairs position (mouse position) and check if ...
                mainMenu.update(target.position);

                // ... we want to start a new game
                if(startingNewGame == true)
                {
                    startNewGame();// start game

                    //we've started a new game so we set to false
                    startingNewGame = false;

                    // and since we started a new game that must mean we are in the middle of a game now
                    mainGameRunning = true;
                }

               
            }
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {

            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            // if we are in the middle of a game ...
            if (mainGameRunning == true)
            {
                // .... then we draw all the appropriate objects
                background.drawSprite(spriteBatch, true);
                bird.drawSprite(spriteBatch, true);
                for (int i = 0; i < MAXBIRDS; i++)
                {
                    birdArray[i].drawSprite(spriteBatch, true);
                }
                target.drawSprite(spriteBatch, true);
                if(bird.isDead == true)
                {
                    blood.drawSprite(spriteBatch, true);
                }
                drawHud(); // a function which draws our heads up display
            }// end if game strated

            // if we are not in the middle of a game then we are in the main menu
            else
            {
                mainMenu.draw(spriteBatch);
                target.drawSprite(spriteBatch, true);
            }
            base.Draw(gameTime);
        }



//================================================================================================
//-------------------------- EXTRA FUNCTIONS *** EXTRA FUNCTIONS --------------------------------
//================================================================================================

        //************* function **********************************
        private void mainGameLoop()
        {
            processInput(); // process our keyboard and mouse

            //update our main bird
            bird.update();

            // update our other birds
            for (int i = 0; i < MAXBIRDS; i++)// goes through the array of birds and updates each one
            {
                birdArray[i].update();
            }

            // if our bird IS NOT dead then we check any possible collisions and decrement score
            if (bird.isDead == false)
            {
                collisionDetection(); // check all possible collisions

                stats.decrementScore(0.4f);// player loses points for every second he uses to try and shoot our bird
            }

            // if our bird IS dead
            else
            {                   
                endScreenTime--;// we decrement the time the end screen appears 

                if (endScreenTime <= 0)// if the end screen time is up...
                {
                    endScreenTime = endScreenMaxTime;//... then we set it back to 0 for the next game

                    mainGameRunning = false; // we are no longer in a game and we want to go back to the main menu
                }
            }
            if (stats.score <= 0)// if we have no points left then its game over
            {
                mainGameRunning = false;// we are no longer in the current game, we go back to the main menu
                
            }
        }
        //************* end function ******************************



        //************* Function **********************************
        //process our keyboard and mouse
        private void processInput()
        {
            target.position = new Vector2(mouse.X, mouse.Y); // we want the target where the mouse is

            preMouse = mouse;// we set the preMouse to the position of the mouse in the last frame....

            mouse = Mouse.GetState();// .... then we update the mouse

            KeyboardState keys = Keyboard.GetState();

            if(keys.IsKeyDown(Keys.Escape))// if we pressed the escape key
            {
                this.Exit(); // exit the program
            }


            //check if the left mouse button has been just pressed
            if (mouse.LeftButton == ButtonState.Pressed &&
               preMouse.LeftButton == ButtonState.Released)
            {
                // if the left mouse button has been pressed and has been released
                mouseLeftJustPressed = true;
            }//end of if mouse is pressed

            // we didnt press the left mouse button
            else
            {
                mouseLeftJustPressed = false;
            }
        }
        //*************** end function ****************************




        //*************** function ********************************
        private void collisionDetection() 
        {
                collisionDetMainBird(); // check collisons for main golden bird
                collisionDetectionBirdArray(); // check collisions for the other black birds
                    
        }//end of collision detection
        // ************** end function ****************************




        //*************** function ********************************
        private void collisionDetMainBird()
        {

            if(mouseLeftJustPressed == true)
            {
                // if our target is in our bird rectangle 
                if (pointInRectangle(target.position,bird.rectangle))
                {
                    //make him fall down the screen
                    bird.directionX = 0;
                    bird.directionY = 1;
                    bird.isDead = true; // the bird is dead
                    blood.X = bird.X;
                    blood.Y = bird.Y;
                    scoreSprite.X = screenBounds.Right/2;
                    scoreSprite.Y = screenBounds.Bottom/2 ;

                }
            }//end of if mouse left just pressed



            // checks to see if our crow is moving out of screen space

            if(bird.edgeContact == false)// only checks when the bird is not already in contact
            {
                // the min and max angles the bird can rotate back at
                int minAngle = -90;
                int maxAngle = 90;
                int angle;

               
                if (bird.Y > screenBounds.Height)// if the bird is moving above the top of the screen
                {
                    bird.edgeContact = true;
                    bird.Y -= 10;// bounce hime back a bit....
                    angle = random.Next(minAngle, maxAngle);//.... then send him in another direction
                    bird.rotate(angle);
                }
                else if (bird.Y < 0)
                {
                    bird.edgeContact = true;
                    bird.Y += 10;
                    angle = random.Next(minAngle, maxAngle);
                    bird.rotate(angle);
                }
                if (bird.X > screenBounds.Width )
                {
                    bird.edgeContact = true;
                    bird.X -= 10;
                    angle = random.Next(minAngle, maxAngle);
                    bird.rotate(angle);
                }
                else if (bird.X < 0)
                {
                    bird.X += 10;
                    bird.edgeContact = true;
                    angle = random.Next(minAngle, maxAngle);
                    bird.rotate(angle);
                }
            }
        }//end of collision detection on main bird

        // ********************* end function *******************************




        //********************** function ***********************************
        private void collisionDetectionBirdArray()// not as detailed  as main bird
        {
            // these bird can only move in 8 diections
            for (int i = 0; i < MAXBIRDS; i++)
            {
                if(birdArray[i].isDead == false)
                {   
                    // if a bird is moving above or below the screen ....
                    if (birdArray[i].position.Y > screenBounds.Height || birdArray[i].position.Y < 0)
                    {
                        // ... send him in the opposite direction
                        birdArray[i].direction = new Vector2(random.Next(-1,1), -birdArray[i].direction.Y);
                    }

                    // do the same if he is moving beyond the lef and right bounds
                    if (birdArray[i].position.X > screenBounds.Width || birdArray[i].position.X < 0)
                    {
                        birdArray[i].direction = new Vector2(-birdArray[i].direction.X, random.Next(-1, 1));
                    }
                }
            }//end of for



            if(mouseLeftJustPressed == true)// did we just release the mouse button
            {
                    
                    for (int current = 0; current < MAXBIRDS; current++)// go through our bird array
                    {
                        if (birdArray[current].isDead == false)// check if the current bird is dead
                        {
                            // if our target is in our current bird rectangle, that must mean we shot it
                            if (pointInRectangle(target.position,birdArray[current].rectangle))
                            {
                                //letd send it down the screen
                                //first set its speed to 10
                                birdArray[current].speed = 10;

                                //then change its direction to facing down
                                birdArray[current].directionX = 0;
                                birdArray[current].directionY = 1;

                                // now lets set it to dead
                                birdArray[current].isDead = true;

                                // you lose points for shooting these birds
                                stats.decrementScore(20);

                            }
                        }
                    }//end of for

            }//end of if left mouse is pressed

        }//end of collision detection on bird array

        //************************** end function ********************************************



        //************************** function ***********************************************
        void drawHud()// just draws text to the screen and also a sprite where the score is positioned
        {
            hud.outText(spriteBatch, arial, "duck X position : ", bird.X.ToString(), screenBounds.Left+20, screenBounds.Top+20, Color.Red);
            hud.outText(spriteBatch, arial, "duck Y position : ", bird.Y.ToString(), screenBounds.Left+20, screenBounds.Top+50, Color.Black);
            scoreSprite.drawSprite(spriteBatch, false);
            hud.outText(spriteBatch,gothic, "Score : ", stats.score.ToString(),scoreSprite.X-130,scoreSprite.Y-20,Color.Blue);
        }
        //************************** end function *******************************************




        //************************* function ************************************************
        // checks if a vector2 point is in a rectangles space
        public static bool pointInRectangle(Vector2 point, Rectangle rectangle)
        {
            bool inRect;// stores true or false

            // if we are in the bounds of the rectangle...
            if (   point.X < rectangle.Right &&
                   point.X > rectangle.Left &&
                   point.Y < rectangle.Bottom &&
                   point.Y > rectangle.Top)
            {
                //... then set to true
                inRect = true;
            }

            // if we are not in the rectangle...
            else
            {
                // ... then set to false
                inRect = false;
            }
            return inRect;//returns true if the point is in the rectangle, otherwise false
        }// end of function point in rectangle

        //************************* end function ********************************************




        //************************* function ************************************************
        public void startNewGame() // initialises required data for new game
        {
            stats.reset();//reset our score 

            for (int current = 0; current < MAXBIRDS; current++)// go through our bird array
            {
                //all of our birds will not be dead when starting a new game
                birdArray[current].isDead = false;

                // give the birds a random position within screen space
                birdArray[current].X = random.Next(20,screenBounds.Right-20);
                birdArray[current].Y = random.Next(20, screenBounds.Bottom - 20);

                // and give them each a random speed
                birdArray[current].speed = random.Next(2,13);
            }


            // our main bird will also be alive
            bird.isDead = false;

            // give the bird a random position within screen space
            bird.X = random.Next(20, screenBounds.Right - 20);
            bird.Y = random.Next(20, screenBounds.Bottom - 20);

            //give it a set speed 
            bird.speed = 20;

            // just posiitons our score sprite back to its original position
            // it is moved to the middle of the screen on the end screen
            scoreSprite.X = screenBounds.Left +180;
            scoreSprite.Y = screenBounds.Bottom-80;
        }
        //***********************************************************************************
    }
}
