using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace duckHunt
{
    public class Hud
    {
        Vector2 FontOrigin = new Vector2(0, 0);
        Vector2 FontPos;

        public void outText(SpriteBatch sb,SpriteFont font, string description, string var, float posX, float posY,Color col)
        {
            sb.Begin(SpriteBlendMode.AlphaBlend, SpriteSortMode.BackToFront, SaveStateMode.SaveState);
            string output = description + var;
            FontPos = new Vector2(posX, posY);

            sb.DrawString(font, output, FontPos, col,
                0, FontOrigin, 1.0f, SpriteEffects.None, 0.5f);

            sb.End();
        }
        public void outSprite(SpriteBatch sb,Texture2D tex, Rectangle rect, Color col)
        {
            sb.Begin(SpriteBlendMode.AlphaBlend,SpriteSortMode.BackToFront,SaveStateMode.SaveState );
            sb.Draw(tex, rect, col);
            sb.End();

        }
    }
    
}
