using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace duckHunt
{
    public class MainMenu
    {
        //the following are TwoDObj's which are basically sprites with positions

        TwoDObj d_mainMenuLogo;  

        TwoDObj d_bloodBackground;

        TwoDObj d_playLogo;// click on to start new game

        TwoDObj d_rulesLogo;// hover over to view rules

        TwoDObj d_rulesScreen;// the texture contains text which tell the rules

        private bool d_inRulesScreen = false;// are we viewing the rules

        public MainMenu(Rectangle screenBounds)// takes the screen space rectangle as a parameter
        {
            //initialise
            d_mainMenuLogo = new TwoDObj(new Vector2(screenBounds.Width / 2, screenBounds.Height / 2),
                                            screenBounds.Width, screenBounds.Height);

            d_playLogo = new TwoDObj(new Vector2((screenBounds.Width/2) ,(screenBounds.Height/2)-10), 200,120);

            d_bloodBackground = new TwoDObj(new Vector2(screenBounds.Width / 2, screenBounds.Height / 2),
                                            screenBounds.Width, screenBounds.Height);

            d_rulesLogo = new TwoDObj(new Vector2((screenBounds.Width / 2), (screenBounds.Height / 2)+80), 200, 100);

            d_rulesScreen = new TwoDObj(new Vector2(screenBounds.Width / 2,screenBounds.Height/4),
                                            screenBounds.Width , (int)(screenBounds.Height/1.8));

        }

        public void update(Vector2 mouse)// takes the mouse position as a parameter
        {
            // if the mouse is in the rectangle which starts a new game
            if (Game1.pointInRectangle(mouse, d_playLogo.rectangle))
            {
                // Highlight it
                d_playLogo.color = Color.Black;

                //leave the rules logo as its normal color
                d_rulesLogo.color = Color.White;

                if( Game1.mouseLeftJustPressed == true)
                {
                    // we clicked on play ....
                    Game1.startingNewGame = true;// ... so we start a new game
                }

                d_inRulesScreen = false; // we are not viewing the rules
            }

            //if we are in the rectangle that shows the rules
            else if (Game1.pointInRectangle(mouse, d_rulesLogo.rectangle))
            {
                //highlight it
                d_rulesLogo.color = Color.Black;

                // leave the play logo as it is as the mouse is not in its rectangle
                d_playLogo.color = Color.White;

                //we are viewing the rules
                d_inRulesScreen = true;
                
            }

            // if the mouse is not in any of the rectangles
            else
            {   
                //leave them as their normal colours
                d_playLogo.color = Color.White;
                d_rulesLogo.color = Color.White;

                //we are not viewing the rules
                d_inRulesScreen = false;
            }


        }

        //uses each TwoDObj's loadTexture to load all the textures
        public void loadTextures(ContentManager Content)
        {
            d_mainMenuLogo.loadTexture(Content, "mainMenu");
            d_playLogo.loadTexture(Content, "play");
            d_bloodBackground.loadTexture(Content,"blood");
            d_rulesLogo.loadTexture(Content,"rules");
            d_rulesScreen.loadTexture(Content,"rulesScreen");
        }
        public void draw(SpriteBatch sb)
        {
            // draw the sprites
            d_mainMenuLogo.drawSprite(sb, true);
            d_bloodBackground.drawSprite(sb, false);
            d_playLogo.drawSprite(sb,true);
            d_rulesLogo.drawSprite(sb,true);

            // if we are viewing the rules ...
            if(d_inRulesScreen == true)
            {
                // ...then show them
                d_rulesScreen.drawSprite(sb,true);
            }
            
        }
    }
	
}
